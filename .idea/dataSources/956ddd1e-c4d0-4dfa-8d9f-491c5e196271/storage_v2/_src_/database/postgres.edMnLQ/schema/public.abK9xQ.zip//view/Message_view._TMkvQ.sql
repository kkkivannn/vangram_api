create view "Message_view"(user_id, name, surname, photo, body, created_at, message_id) as
SELECT u.id AS user_id,
       u.name,
       u.surname,
       u.photo,
       m.body,
       m.created_at,
       m.id AS message_id
FROM "Message" m
         JOIN "User" u ON m.id_user = u.id;

alter table "Message_view"
    owner to admin;

